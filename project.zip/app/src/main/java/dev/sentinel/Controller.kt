package dev.sentinel

object Controller {
    private const val CH = "sentinel_out"
    private val PKG = Regex("^[A-Za-z0-9._]+$")
    private val IFACE = Regex("^[a-z0-9+]+$")
    private val TOOLS = listOf("iptables", "ip6tables")

    // Loopback is never blocked so local IPC (and root manager) keeps working.
    private fun spec(uid: Int, iface: String?): String {
        val o = iface?.takeIf { IFACE.matches(it) }?.let { "-o $it" } ?: "! -o lo"
        return "-m owner --uid-owner $uid $o -j REJECT"
    }

    fun setup() = TOOLS.forEach { t ->
        Root.ok("$t -w -N $CH 2>/dev/null; $t -w -C OUTPUT -j $CH 2>/dev/null || $t -w -I OUTPUT 1 -j $CH")
    }

    fun block(uid: Int, iface: String? = null) {
        val s = spec(uid, iface)
        TOOLS.forEach { t -> Root.ok("$t -w -C $CH $s 2>/dev/null || $t -w -A $CH $s") }
    }

    fun unblock(uid: Int, iface: String? = null) {
        val s = spec(uid, iface)
        TOOLS.forEach { t -> Root.ok("$t -w -D $CH $s 2>/dev/null") }
    }

    fun unblockAll() = TOOLS.forEach { Root.ok("$it -w -F $CH") }

    fun freeze(pid: Int) = Root.ok("kill -STOP $pid")
    fun resume(pid: Int) = Root.ok("kill -CONT $pid")
    fun kill(pid: Int) = Root.ok("kill -9 $pid")
    fun forceStop(pkg: String) = PKG.matches(pkg) && Root.ok("am force-stop $pkg")
    fun disableComponent(pkg: String, cls: String) = PKG.matches(pkg) && PKG.matches(cls) && Root.ok("pm disable $pkg/$cls")
    fun revoke(pkg: String, op: String) = PKG.matches(pkg) && PKG.matches(op) && Root.ok("cmd appops set $pkg $op ignore")
}
