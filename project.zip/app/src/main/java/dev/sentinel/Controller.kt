package dev.sentinel

object Controller {
    private const val CH = "sentinel_out"
    private val PKG = Regex("^[A-Za-z0-9._]+$")
    private val IFACE = Regex("^[a-z0-9+]+$")

    /** Create our own chain and hook it at the top of OUTPUT (idempotent). */
    fun setup() = listOf("iptables", "ip6tables").forEach { t ->
        Root.ok("$t -w -N $CH 2>/dev/null; $t -w -C OUTPUT -j $CH 2>/dev/null || $t -w -I OUTPUT 1 -j $CH")
    }

    /** Block a UID's outgoing traffic. iface: e.g. "wlan+" or "rmnet+" (null = all). */
    fun block(uid: Int, iface: String? = null) {
        val o = iface?.takeIf { IFACE.matches(it) }?.let { "-o $it" } ?: ""
        listOf("iptables", "ip6tables").forEach { t ->
            Root.ok("$t -w -C $CH $o -m owner --uid-owner $uid -j REJECT 2>/dev/null || $t -w -A $CH $o -m owner --uid-owner $uid -j REJECT")
        }
    }

    fun unblockAll() = listOf("iptables", "ip6tables").forEach { Root.ok("$it -w -F $CH") }

    fun freeze(pid: Int) = Root.ok("kill -STOP $pid")
    fun resume(pid: Int) = Root.ok("kill -CONT $pid")
    fun kill(pid: Int) = Root.ok("kill -9 $pid")
    fun forceStop(pkg: String) = PKG.matches(pkg) && Root.ok("am force-stop $pkg")
    fun disableComponent(pkg: String, cls: String) = PKG.matches(pkg) && PKG.matches(cls) && Root.ok("pm disable $pkg/$cls")
    fun revoke(pkg: String, op: String) = PKG.matches(pkg) && PKG.matches(op) && Root.ok("cmd appops set $pkg $op ignore")
}
