package dev.sentinel

data class SvcInfo(val name: String, val foreground: Boolean)
data class Detail(val services: List<SvcInfo>, val clients: List<String>, val parents: List<String>)

object Dumpsys {
    private val PKG = Regex("^[A-Za-z0-9._]+$")
    private val svcRe = Regex("""ServiceRecord\{\w+ u\d+ ([^\s}]+)\}""")
    private val procRe = Regex("""ProcessRecord\{\w+ \d+:([^/\s}]+)/""")

    fun cmdline(pid: Int): String =
        Root.run("tr '\\0' ' ' < /proc/$pid/cmdline 2>/dev/null").firstOrNull()?.trim().orEmpty()

    /** Best-effort: running services of the packages, other components bound to them, and parent process names. */
    fun detailFor(pkgs: List<String>, ppids: List<Int>): Detail {
        val svcs = ArrayList<SvcInfo>()
        val clients = LinkedHashSet<String>()
        for (pkg in pkgs) {
            if (!PKG.matches(pkg)) continue
            var cur: String? = null
            var fg = false
            fun flush() { cur?.let { svcs.add(SvcInfo(it, fg)) }; cur = null; fg = false }
            for (l in Root.run("dumpsys activity services $pkg")) {
                val m = svcRe.find(l)
                if (m != null) { flush(); cur = m.groupValues[1]; continue }
                if (l.contains("isForeground=true")) fg = true
                procRe.findAll(l).forEach { mm ->
                    val n = mm.groupValues[1]
                    if (!n.startsWith(pkg)) clients.add(n)
                }
            }
            flush()
        }
        val parents = ppids.distinct().take(6).map { cmdline(it) }.filter { it.isNotEmpty() }
        return Detail(svcs.distinctBy { it.name }, clients.toList(), parents)
    }
}
