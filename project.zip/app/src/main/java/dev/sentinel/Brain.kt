package dev.sentinel

import java.util.concurrent.ConcurrentHashMap

enum class AiMode { OFF, SAFE, SMART }
enum class Verdict { UNKNOWN, TRIAL, SAFE, REMOVABLE, ESSENTIAL, PROTECTED }

data class Learned(
    val pkg: String, val label: String, val verdict: Verdict = Verdict.UNKNOWN,
    val trims: Int = 0, val clean: Int = 0, val impacts: Int = 0, val respawns: Int = 0,
    val savedMb: Long = 0, val lastTrim: Long = 0, val lastFg: Long = 0,
    val firstSeen: Long = System.currentTimeMillis(), val nextTry: Long = 0, val restricted: Boolean = false
)

private class Exp(
    val pkg: String, val label: String, val uid: Int, val startedAt: Long,
    val pssBefore: Long, val sysPid: Int, val pre: Set<String>
) { var respawned = false }

/**
 * Adaptive RAM manager. One experiment at a time:
 * clean a background app -> watch the system for crashes/ANRs/system_server restarts -> learn.
 * Verdicts: TRIAL -> SAFE (3 clean runs) -> REMOVABLE (6 clean runs, 3 days unused).
 * Impact seen -> rolled back; twice -> ESSENTIAL. system_server restart -> everything off.
 */
class Brain(private val store: Store, private val selfPkg: String) {
    @Volatile var mode: AiMode = try { AiMode.valueOf(store.setting("ai_mode") ?: "SAFE") } catch (e: Exception) { AiMode.SAFE }
        private set
    @Volatile var status: String = "جاهز"; private set
    @Volatile var savedTotal: Long = store.setting("ai_saved")?.toLongOrNull() ?: 0L; private set

    private val map = ConcurrentHashMap<String, Learned>().also { m -> store.allLearn().forEach { m[it.pkg] = it } }
    private val dirty: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
    private val depCache = HashMap<String, Pair<Long, Boolean>>()
    private var exp: Exp? = null
    private var lastTrimAt = 0L
    private var lastFlush = 0L

    fun list(): List<Learned> = map.values.sortedBy { it.label.lowercase() }

    private fun get(pkg: String, label: String): Learned = map.getOrPut(pkg) { Learned(pkg, label) }
    private fun put(l: Learned) { map[l.pkg] = l; dirty.add(l.pkg) }

    fun setMode(m: AiMode) {
        mode = m
        store.setSetting("ai_mode", m.name)
        if (m == AiMode.OFF) {
            exp = null
            map.values.filter { it.restricted }.forEach { Controller.restrictBg(it.pkg, false); put(it.copy(restricted = false)) }
        }
    }

    fun setVerdict(pkg: String, v: Verdict) {
        val l = map[pkg] ?: return
        if (l.restricted) Controller.restrictBg(pkg, false)
        put(l.copy(verdict = v, nextTry = 0, restricted = false,
            clean = if (v == Verdict.UNKNOWN) 0 else l.clean, impacts = if (v == Verdict.UNKNOWN) 0 else l.impacts))
    }

    private fun flushIfDue(now: Long) {
        if (now - lastFlush < 60_000) return
        lastFlush = now
        for (p in dirty.toList()) { map[p]?.let { store.putLearn(it) }; dirty.remove(p) }
        store.setSetting("ai_saved", savedTotal.toString())
    }

    fun step(rows: List<AppRow>, mem: MemInfo, fg: String?) {
        val now = System.currentTimeMillis()
        flushIfDue(now)
        if (mode == AiMode.OFF) { status = "متوقف"; return }
        if (fg != null) {
            val lab = rows.firstOrNull { r -> r.pkgs.any { it.pkg == fg } }?.pkgs?.firstOrNull { it.pkg == fg }?.label ?: fg
            put(get(fg, lab).copy(lastFg = now))
        }
        val e = exp
        if (e != null) {
            if (fg == e.pkg) { exp = null; status = "أُلغيت التجربة: فتحتَ ${e.label}"; return }
            evaluate(e, rows, now)
            return
        }
        if (now - lastTrimAt < 60_000) { status = "ينتظر قبل التجربة التالية"; return }
        pick(rows, mem, fg, now)
    }

    private fun pick(rows: List<AppRow>, mem: MemInfo, fg: String?, now: Long) {
        val pressure = mem.totalMb > 0 && mem.availMb * 100 < mem.totalMb * 30
        var best: AppRow? = null
        var bestScore = -1L
        for (r in rows) {
            if (r.pkgs.size != 1 || r.procs.isEmpty()) continue
            val p = r.pkgs[0]
            if (p.pkg == selfPkg || p.pkg == fg || Guard.isProtected(p.pkg)) continue
            if (!(r.importance == Importance.USER || (r.importance == Importance.SYSTEM && mode == AiMode.SMART))) continue
            val l = get(p.pkg, p.label)
            if (l.verdict == Verdict.ESSENTIAL || l.verdict == Verdict.PROTECTED) continue
            if (now < l.nextTry || now - l.lastFg < 300_000L) continue
            val proven = l.verdict == Verdict.SAFE || l.verdict == Verdict.REMOVABLE
            if (now - l.lastTrim < (if (proven) 600_000L else 1_800_000L)) continue
            val rss = r.rssMb
            if (proven) { if (rss < 30) continue } else if (!((pressure && rss >= 30) || rss >= 150)) continue
            val score = rss + store.countEvents(r.uid, "NEW_PORT", now - 86_400_000L) * 100
            if (score > bestScore) { best = r; bestScore = score }
        }
        val r = best
        if (r == null) { status = "لا مرشحين الآن" + (if (pressure) " (ضغط على الذاكرة)" else ""); return }
        val p = r.pkgs[0]
        if (hasDependents(p.pkg, now)) {
            put(get(p.pkg, p.label).copy(nextTry = now + 3_600_000L))
            status = "تخطّيت ${p.label}: مكوّنات أخرى تعتمد عليه"
            return
        }
        start(r, now)
    }

    private fun hasDependents(pkg: String, now: Long): Boolean {
        depCache[pkg]?.let { if (now - it.first < 1_800_000L) return it.second }
        val d = Dumpsys.detailFor(listOf(pkg), emptyList())
        val v = d.clients.isNotEmpty() || d.services.any { it.foreground }
        depCache[pkg] = now to v
        return v
    }

    private fun start(r: AppRow, now: Long) {
        val p = r.pkgs[0]
        val before = Sys.pssMb(r.procs.map { it.pid })
        val pre = Sys.problemsSince(now - 300_000L, p.pkg, selfPkg).toSet()
        val sp = Sys.systemServerPid()
        Controller.softKill(p.pkg)
        val l = get(p.pkg, p.label)
        put(l.copy(verdict = if (l.verdict == Verdict.UNKNOWN) Verdict.TRIAL else l.verdict, lastTrim = now))
        exp = Exp(p.pkg, p.label, r.uid, now, before, sp, pre)
        lastTrimAt = now
        store.addEvent(r.uid, p.label, "AI", "تجربة تنظيف ${p.label} (~${before}MB) وأراقب رد فعل النظام")
        status = "يراقب ${p.label}…"
    }

    private fun evaluate(e: Exp, rows: List<AppRow>, now: Long) {
        val age = now - e.startedAt
        val sp = Sys.systemServerPid()
        if (e.sysPid > 0 && sp > 0 && sp != e.sysPid) { severe(e); return }
        val probs = Sys.problemsSince(e.startedAt, e.pkg, selfPkg).filter { it !in e.pre }
        if (probs.isNotEmpty()) { impact(e, probs, now); return }
        val row = rows.firstOrNull { it.uid == e.uid }
        if (age > 8_000L && row != null && row.procs.isNotEmpty()) e.respawned = true
        if (age < 90_000L) { status = "يراقب ${e.label}… ${(90_000L - age) / 1000}ث"; return }
        finish(e, row, now)
    }

    private fun finish(e: Exp, row: AppRow?, now: Long) {
        exp = null
        val l = map[e.pkg] ?: return
        val after = if (e.respawned && row != null) Sys.pssMb(row.procs.map { it.pid }) else 0L
        val saved = maxOf(0L, e.pssBefore - after)
        savedTotal += saved
        var nl = l.copy(trims = l.trims + 1, clean = l.clean + 1, respawns = l.respawns + (if (e.respawned) 1 else 0),
            savedMb = l.savedMb + saved, lastTrim = now)
        if (e.respawned) nl = nl.copy(nextTry = now + 1_800_000L * (1L shl minOf(nl.respawns, 4)))   // back off if it keeps returning
        if (nl.clean >= 3 && (nl.verdict == Verdict.UNKNOWN || nl.verdict == Verdict.TRIAL)) {
            nl = nl.copy(verdict = Verdict.SAFE)
            store.addEvent(e.uid, e.label, "AI", "تعلّمت: ${e.label} آمن للإيقاف (3 تجارب بلا تأثير)")
        }
        val day = 86_400_000L
        if (nl.verdict == Verdict.SAFE && nl.clean >= 6 && nl.impacts == 0 && now - nl.firstSeen > 3 * day && now - nl.lastFg > 3 * day) {
            nl = nl.copy(verdict = Verdict.REMOVABLE)
            store.addEvent(e.uid, e.label, "AI", "صنّفت ${e.label} قابلًا للإزالة: 6 تجارب بلا تأثير وغير مستخدم منذ 3 أيام")
        }
        if (e.respawned && nl.respawns >= 3 && mode == AiMode.SMART && !nl.restricted && !Guard.hasNotif(e.pkg) &&
            (nl.verdict == Verdict.SAFE || nl.verdict == Verdict.REMOVABLE)) {
            if (Controller.restrictBg(e.pkg, true)) {
                nl = nl.copy(restricted = true)
                store.addEvent(e.uid, e.label, "AI", "${e.label} يعيد تشغيل نفسه، قيّدت عمله في الخلفية")
            }
        }
        put(nl)
        store.addEvent(e.uid, e.label, "AI", "انتهت التجربة: وفّر ${saved}MB" + (if (e.respawned) " — لكنه عاد للعمل" else ""))
        status = "اكتملت تجربة ${e.label}"
    }

    private fun impact(e: Exp, probs: List<String>, now: Long) {
        exp = null
        val l = map[e.pkg] ?: return
        if (l.restricted) Controller.restrictBg(e.pkg, false)
        val imp = l.impacts + 1
        put(l.copy(impacts = imp, clean = 0, restricted = false, nextTry = now + 12 * 3_600_000L,
            verdict = if (imp >= 2) Verdict.ESSENTIAL else Verdict.TRIAL))
        store.addEvent(e.uid, e.label, "AI",
            "تأثير محتمل بعد تنظيف ${e.label}: ${probs.take(3).joinToString()} — " + (if (imp >= 2) "صنّفته ضروريًا" else "سأعيد المحاولة بعد 12 ساعة"))
        status = "رصدت تأثيرًا بعد ${e.label}"
    }

    private fun severe(e: Exp) {
        exp = null
        map[e.pkg]?.let { put(it.copy(verdict = Verdict.ESSENTIAL, impacts = it.impacts + 1)) }
        setMode(AiMode.OFF)
        store.addEvent(-1, "الذكاء", "AI", "أوقفت المدير الذكي: أُعيد تشغيل system_server بعد تنظيف ${e.label}")
        status = "أُوقف تلقائيًا للسلامة"
    }
}
