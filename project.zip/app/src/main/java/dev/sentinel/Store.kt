package dev.sentinel

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Store(ctx: Context) : SQLiteOpenHelper(ctx, "sentinel.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, uid INTEGER, label TEXT, kind TEXT, detail TEXT)")
        db.execSQL("CREATE TABLE dests(k TEXT PRIMARY KEY)")
        db.execSQL("CREATE TABLE blocks(uid INTEGER PRIMARY KEY)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun addEvent(uid: Int, label: String, kind: String, detail: String) {
        val db = writableDatabase
        db.execSQL("INSERT INTO events(ts,uid,label,kind,detail) VALUES(?,?,?,?,?)",
            arrayOf<Any>(System.currentTimeMillis(), uid, label, kind, detail))
        if (Math.random() < 0.02) db.execSQL("DELETE FROM events WHERE id < (SELECT MAX(id) FROM events) - 20000")
    }

    fun recentEvents(limit: Int): List<Event> =
        readableDatabase.rawQuery("SELECT id,ts,uid,label,kind,detail FROM events ORDER BY id DESC LIMIT $limit", null).use { c ->
            val out = ArrayList<Event>()
            while (c.moveToNext()) out.add(Event(c.getLong(0), c.getLong(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5)))
            out
        }

    fun loadDests(): List<String> =
        readableDatabase.rawQuery("SELECT k FROM dests", null).use { c ->
            val out = ArrayList<String>()
            while (c.moveToNext()) out.add(c.getString(0))
            out
        }

    fun addDests(keys: List<String>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            keys.forEach { db.execSQL("INSERT OR IGNORE INTO dests(k) VALUES(?)", arrayOf<Any>(it)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun blocks(): List<Int> =
        readableDatabase.rawQuery("SELECT uid FROM blocks", null).use { c ->
            val out = ArrayList<Int>()
            while (c.moveToNext()) out.add(c.getInt(0))
            out
        }

    fun setBlocked(uid: Int, on: Boolean) {
        if (on) writableDatabase.execSQL("INSERT OR IGNORE INTO blocks(uid) VALUES(?)", arrayOf<Any>(uid))
        else writableDatabase.execSQL("DELETE FROM blocks WHERE uid=?", arrayOf<Any>(uid))
    }
    fun clearBlocks() = writableDatabase.execSQL("DELETE FROM blocks")

    fun setting(k: String): String? =
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else null }

    fun setSetting(k: String, v: String) =
        writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf<Any>(k, v))
}
