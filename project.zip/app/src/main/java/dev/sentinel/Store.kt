package dev.sentinel

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Store(ctx: Context) : SQLiteOpenHelper(ctx, "sentinel.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, uid INTEGER, label TEXT, kind TEXT, detail TEXT)")
        db.execSQL("CREATE TABLE dests(k TEXT PRIMARY KEY)")
        db.execSQL("CREATE TABLE blocks(uid INTEGER PRIMARY KEY)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)")
        createLearn(db)
    }
    private fun createLearn(db: SQLiteDatabase) = db.execSQL(
        "CREATE TABLE IF NOT EXISTS learn(pkg TEXT PRIMARY KEY, label TEXT, verdict TEXT, trims INTEGER, clean INTEGER, impacts INTEGER, " +
            "respawns INTEGER, saved INTEGER, last_trim INTEGER, last_fg INTEGER, first_seen INTEGER, next_try INTEGER, restricted INTEGER)")
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) { createLearn(db) }

    fun countEvents(uid: Int, kind: String, since: Long): Long =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM events WHERE uid=? AND kind=? AND ts>=?", arrayOf(uid.toString(), kind, since.toString()))
            .use { if (it.moveToFirst()) it.getLong(0) else 0L }

    fun allLearn(): List<Learned> =
        readableDatabase.rawQuery("SELECT pkg,label,verdict,trims,clean,impacts,respawns,saved,last_trim,last_fg,first_seen,next_try,restricted FROM learn", null).use { c ->
            val out = ArrayList<Learned>()
            while (c.moveToNext()) out.add(Learned(
                c.getString(0), c.getString(1), Verdict.values().firstOrNull { it.name == c.getString(2) } ?: Verdict.UNKNOWN,
                c.getInt(3), c.getInt(4), c.getInt(5), c.getInt(6), c.getLong(7), c.getLong(8), c.getLong(9), c.getLong(10), c.getLong(11), c.getInt(12) != 0))
            out
        }

    fun putLearn(l: Learned) = writableDatabase.execSQL(
        "INSERT OR REPLACE INTO learn VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        arrayOf<Any>(l.pkg, l.label, l.verdict.name, l.trims, l.clean, l.impacts, l.respawns, l.savedMb, l.lastTrim, l.lastFg, l.firstSeen, l.nextTry, if (l.restricted) 1 else 0))

    fun addEvent(uid: Int, label: String, kind: String, detail: String) {
        val db = writableDatabase
        db.execSQL("INSERT INTO events(ts,uid,label,kind,detail) VALUES(?,?,?,?,?)",
            arrayOf<Any>(System.currentTimeMillis(), uid, label, kind, detail))
        if (Math.random() < 0.02) db.execSQL("DELETE FROM events WHERE id < (SELECT MAX(id) FROM events) - 20000")
    }

    fun recentEvents(limit: Int): List<Event> =
        readableDatabase.rawQuery("SELECT id,ts,uid,label,kind,detail FROM events ORDER BY id DESC LIMIT $limit", null).use { c ->
            val out = ArrayList<Event>()
            while (c.moveToNext()) out.add(Event(c.getLong(0), c.getLong(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5)))
            out
        }

    fun loadDests(): List<String> =
        readableDatabase.rawQuery("SELECT k FROM dests", null).use { c ->
            val out = ArrayList<String>()
            while (c.moveToNext()) out.add(c.getString(0))
            out
        }

    fun addDests(keys: List<String>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            keys.forEach { db.execSQL("INSERT OR IGNORE INTO dests(k) VALUES(?)", arrayOf<Any>(it)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun blocks(): List<Int> =
        readableDatabase.rawQuery("SELECT uid FROM blocks", null).use { c ->
            val out = ArrayList<Int>()
            while (c.moveToNext()) out.add(c.getInt(0))
            out
        }

    fun setBlocked(uid: Int, on: Boolean) {
        if (on) writableDatabase.execSQL("INSERT OR IGNORE INTO blocks(uid) VALUES(?)", arrayOf<Any>(uid))
        else writableDatabase.execSQL("DELETE FROM blocks WHERE uid=?", arrayOf<Any>(uid))
    }
    fun clearBlocks() = writableDatabase.execSQL("DELETE FROM blocks")

    fun setting(k: String): String? =
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else null }

    fun setSetting(k: String, v: String) =
        writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf<Any>(k, v))
}
