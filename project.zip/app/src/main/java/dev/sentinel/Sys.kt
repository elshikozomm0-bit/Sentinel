package dev.sentinel

/** System probes: memory, foreground app, screen state, crash/ANR health. */
object Sys {
    private val actRe = Regex("""ActivityRecord\{\w+ u\d+ ([^/\s]+)/""")
    private val PSS = """for p in §PIDS; do while read -r k v r; do case §k in Pss:) echo §v;; esac; done 2>/dev/null < /proc/§p/smaps_rollup; done"""

    fun mem(): MemInfo {
        val m = HashMap<String, Long>()
        for (l in Root.run("cat /proc/meminfo")) {
            val v = l.substringAfter(':').trim().substringBefore(' ').toLongOrNull() ?: continue
            m[l.substringBefore(':')] = v
        }
        fun mb(k: String) = (m[k] ?: 0L) / 1024
        return MemInfo(mb("MemTotal"), mb("MemAvailable"), mb("SwapTotal"), mb("SwapFree"))
    }

    /** Proportional set size in MB (accurate, but costly: only call for a few pids). */
    fun pssMb(pids: List<Int>): Long {
        if (pids.isEmpty()) return 0L
        val cmd = PSS.replace("§PIDS", pids.joinToString(" ")).replace('§', '$')
        return Root.run(cmd).sumOf { it.trim().toLongOrNull() ?: 0L } / 1024
    }

    fun foreground(): String? =
        Root.run("dumpsys activity activities | grep -m6 -E 'topResumedActivity|ResumedActivity'")
            .firstNotNullOfOrNull { actRe.find(it)?.groupValues?.get(1) }

    fun awake(): Boolean =
        Root.run("dumpsys power | grep -m1 'mWakefulness='").firstOrNull()?.contains("Awake") ?: true

    fun systemServerPid(): Int =
        Root.run("pidof system_server").firstOrNull()?.trim()?.split(" ")?.firstOrNull()?.toIntOrNull() ?: -1

    /** Crashes/ANRs of processes other than [ignore]/[self] since [sinceMs]. */
    fun problemsSince(sinceMs: Long, ignore: String, self: String): List<String> {
        val t = "%d.%03d".format(sinceMs / 1000, sinceMs % 1000)
        val out = ArrayList<String>()
        for (l in Root.run("logcat -b crash -d -v epoch -T $t 2>/dev/null | grep 'Process: '")) {
            val n = Regex("Process: ([A-Za-z0-9._:]+)").find(l)?.groupValues?.get(1) ?: continue
            if (!n.startsWith(ignore) && !n.startsWith(self)) out.add("crash:$n")
        }
        for (l in Root.run("logcat -b events -d -v epoch -T $t am_anr:I am_crash:I '*:S' 2>/dev/null")) {
            val m = Regex("am_(anr|crash): \\[[^,]*,[^,]*,([^,\\]]+)").find(l) ?: continue
            val n = m.groupValues[2]
            if (!n.startsWith(ignore) && !n.startsWith(self)) out.add("${m.groupValues[1]}:$n")
        }
        return out.distinct()
    }
}

/** Packages the automation must never touch. */
object Guard {
    private val PKG = Regex("^[A-Za-z0-9._]+$")
    private val svcRe = Regex("""ServiceRecord\{\w+ u\d+ ([^\s}]+)\}""")
    private val defaults = setOf(
        "android", "com.android.systemui", "com.android.phone", "com.android.settings", "com.android.vending",
        "com.google.android.gms", "com.google.android.gsf", "com.google.android.webview",
        "me.weishu.kernelsu", "com.topjohnwu.magisk", "com.android.ims", "com.google.android.ims"
    )
    private val prefixes = listOf(
        "com.android.providers.", "com.android.server.", "com.android.inputmethod", "com.google.android.inputmethod",
        "com.android.bluetooth", "com.android.nfc", "com.android.shell", "com.qualcomm.", "com.mediatek."
    )
    @Volatile private var dynamic: Set<String> = emptySet()
    @Volatile private var notif: Set<String> = emptySet()
    @Volatile private var fgSvc: Set<String> = emptySet()

    fun isProtected(pkg: String) = pkg in defaults || prefixes.any { pkg.startsWith(it) } || pkg in dynamic || pkg in fgSvc
    fun hasNotif(pkg: String) = pkg in notif

    fun refresh() {
        val dyn = HashSet<String>()
        fun add(s: String?) {
            val p = s?.trim()?.substringBefore('/') ?: return
            if (p.matches(PKG)) dyn.add(p)
        }
        Root.run("cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME | tail -n 1").forEach { add(it) }
        Root.run("settings get secure default_input_method").forEach { add(it) }
        for (r in listOf("DIALER", "SMS", "HOME", "ASSISTANT", "BROWSER"))
            Root.run("cmd role get-role-holders --user 0 android.app.role.$r").forEach { add(it) }
        for (l in Root.run("settings get secure enabled_accessibility_services")) l.split(':').forEach { add(it) }
        dynamic = dyn

        val nf = HashSet<String>()
        for (l in Root.run("dumpsys notification --noredact | grep -o 'pkg=[A-Za-z0-9._]*'")) nf.add(l.removePrefix("pkg="))
        notif = nf

        val fs = HashSet<String>()
        var cur: String? = null
        for (l in Root.run("dumpsys activity services | grep -E 'ServiceRecord\\{|isForeground=true'")) {
            val m = svcRe.find(l)
            if (m != null) cur = m.groupValues[1].substringBefore('/')
            else { val c = cur; if (c != null) fs.add(c) }
        }
        fgSvc = fs
    }
}
