package dev.sentinel

data class Proc(val pid: Int, val uid: Int, val name: String, val rssKb: Long)

object ProcMonitor {
    private var lastTicks = mapOf<Int, Long>()
    private var lastTime = 0L

    fun processes(): List<Proc> =
        Root.run("ps -A -o PID,UID,RSS,NAME").drop(1).mapNotNull {
            val f = it.trim().split(Regex("\\s+"), 4)
            if (f.size < 4) null else Proc(f[0].toIntOrNull() ?: return@mapNotNull null,
                f[1].toIntOrNull() ?: return@mapNotNull null, f[3], f[2].toLongOrNull() ?: 0)
        }

    /** CPU percent per PID since the previous call (100 ticks/s). */
    fun cpuByPid(): Map<Int, Double> {
        val now = System.nanoTime()
        val ticks = mutableMapOf<Int, Long>()
        Root.run("for f in /proc/[0-9]*/stat; do cat \$f 2>/dev/null; done").forEach { l ->
            val pid = l.substringBefore(' ').toIntOrNull() ?: return@forEach
            val rest = l.substring(l.lastIndexOf(')') + 2).split(' ')
            if (rest.size > 12) ticks[pid] = (rest[11].toLongOrNull() ?: 0) + (rest[12].toLongOrNull() ?: 0)
        }
        val dt = (now - lastTime) / 1e9
        val out = if (lastTime == 0L || dt <= 0) emptyMap()
        else ticks.mapValues { (p, t) -> ((t - (lastTicks[p] ?: t)) / (dt * 100.0)) * 100 }
        lastTicks = ticks; lastTime = now
        return out
    }
}
