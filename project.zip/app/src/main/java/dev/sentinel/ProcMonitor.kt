package dev.sentinel

object ProcMonitor {
    private var lastTicks = mapOf<Int, Long>()
    private var lastTime = 0L

    // § becomes $ (avoids Kotlin interpolation). Shell builtins only: no fork per process.
    private val SCRIPT = """
for p in /proc/[0-9]*; do uid=0; rss=0; pp=0; name=; read -r name 2>/dev/null < §p/comm;
while read -r k v r; do case §k in Uid:) uid=§v;; PPid:) pp=§v;; VmRSS:) rss=§v;; esac; done 2>/dev/null < §p/status;
echo "§{p#/proc/}|§pp|§uid|§rss|§name"; done
""".replace('§', '$').replace("\n", " ")

    fun sample(): List<Proc> {
        val cpu = cpuByPid()
        return Root.run(SCRIPT).mapNotNull { l ->
            val f = l.split("|", limit = 5)
            if (f.size < 5) return@mapNotNull null
            val pid = f[0].toIntOrNull() ?: return@mapNotNull null
            val uid = f[2].toIntOrNull() ?: return@mapNotNull null
            Proc(pid, f[1].toIntOrNull() ?: 0, uid, f[4], f[3].toLongOrNull() ?: 0, cpu[pid] ?: 0.0)
        }
    }

    /** CPU percent per PID since the previous call (100 ticks/s). */
    private fun cpuByPid(): Map<Int, Double> {
        val now = System.nanoTime()
        val ticks = mutableMapOf<Int, Long>()
        Root.run("cat /proc/[0-9]*/stat 2>/dev/null").forEach { l ->
            val pid = l.substringBefore(' ').toIntOrNull() ?: return@forEach
            val i = l.lastIndexOf(')')
            if (i < 0) return@forEach
            val rest = l.substring(i + 2).split(' ')
            if (rest.size > 12) ticks[pid] = (rest[11].toLongOrNull() ?: 0) + (rest[12].toLongOrNull() ?: 0)
        }
        val dt = (now - lastTime) / 1e9
        val out = if (lastTime == 0L || dt <= 0) emptyMap()
        else ticks.mapValues { (p, t) -> ((t - (lastTicks[p] ?: t)) / (dt * 100.0)) * 100 }
        lastTicks = ticks; lastTime = now
        return out
    }
}
