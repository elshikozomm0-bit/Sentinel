package dev.sentinel

data class Proc(val pid: Int, val uid: Int, val name: String, val rssKb: Long)

object ProcMonitor {
    private var lastTicks = mapOf<Int, Long>()
    private var lastTime = 0L

    // § is replaced by $ (avoids Kotlin string interpolation). Uses shell builtins only: no forks per process.
    private val SCRIPT = """
for p in /proc/[0-9]*; do uid=0; rss=0; name=; read -r name < §p/comm 2>/dev/null;
while read -r k v r; do case §k in Uid:) uid=§v;; VmRSS:) rss=§v;; esac; done < §p/status 2>/dev/null;
echo "§{p#/proc/}|§uid|§rss|§name"; done
""".replace('§', '$').replace("\n", " ")

    fun processes(): List<Proc> = Root.run(SCRIPT).mapNotNull {
        val f = it.split("|", limit = 4)
        if (f.size < 4) return@mapNotNull null
        Proc(
            f[0].toIntOrNull() ?: return@mapNotNull null,
            f[1].toIntOrNull() ?: return@mapNotNull null,
            f[3], f[2].toLongOrNull() ?: 0
        )
    }

    /** CPU percent per PID since the previous call (100 ticks/s). */
    fun cpuByPid(): Map<Int, Double> {
        val now = System.nanoTime()
        val ticks = mutableMapOf<Int, Long>()
        Root.run("cat /proc/[0-9]*/stat 2>/dev/null").forEach { l ->
            val pid = l.substringBefore(' ').toIntOrNull() ?: return@forEach
            val i = l.lastIndexOf(')')
            if (i < 0) return@forEach
            val rest = l.substring(i + 2).split(' ')
            if (rest.size > 12) ticks[pid] = (rest[11].toLongOrNull() ?: 0) + (rest[12].toLongOrNull() ?: 0)
        }
        val dt = (now - lastTime) / 1e9
        val out = if (lastTime == 0L || dt <= 0) emptyMap()
        else ticks.mapValues { (p, t) -> ((t - (lastTicks[p] ?: t)) / (dt * 100.0)) * 100 }
        lastTicks = ticks; lastTime = now
        return out
    }
}
