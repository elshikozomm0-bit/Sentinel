package dev.sentinel

import android.content.pm.PackageManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

object Icons {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()
    fun get(pm: PackageManager, pkg: String): ImageBitmap? {
        cache[pkg]?.let { return it }
        return try {
            val b = pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            cache[pkg] = b
            b
        } catch (e: Exception) { null }
    }
}

/** App icon, or a gear for native services that have no package. */
@Composable
fun AppIcon(pkg: String?, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = if (pkg == null) null else withContext(Dispatchers.IO) { Icons.get(ctx.packageManager, pkg) }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size))
    else Box(
        Modifier.size(size).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("⚙") }
}
