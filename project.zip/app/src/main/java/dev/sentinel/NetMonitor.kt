package dev.sentinel

object NetMonitor {
    private val states = mapOf("01" to "ESTABLISHED", "02" to "SYN_SENT", "06" to "TIME_WAIT", "08" to "CLOSE_WAIT", "0A" to "LISTEN")

    /** All connected sockets with owning UID and, where possible, owning PID (inode -> /proc/PID/fd). */
    fun snapshot(): List<Conn> {
        val owners = socketOwners()
        return listOf("tcp", "tcp6", "udp", "udp6").flatMap { p ->
            Root.run("cat /proc/net/$p").drop(1).mapNotNull { parse(p, it) }
        }.filter { !it.unconnected }.map { it.copy(pid = owners[it.inode] ?: -1) }
    }

    private fun socketOwners(): Map<Long, Int> {
        val map = HashMap<Long, Int>()
        var pid = -1
        Root.run("ls -l /proc/[0-9]*/fd 2>/dev/null | grep -E ':\$|socket:\\['").forEach { l ->
            if (l.startsWith("/proc/")) {
                pid = l.removePrefix("/proc/").substringBefore('/').toIntOrNull() ?: -1
            } else {
                val i = l.indexOf("socket:[")
                if (i >= 0 && pid >= 0) l.substring(i + 8).substringBefore(']').toLongOrNull()?.let { map[it] = pid }
            }
        }
        return map
    }

    private fun parse(p: String, line: String): Conn? {
        val f = line.trim().split(Regex("\\s+"))
        if (f.size < 10) return null
        val uid = f[7].toIntOrNull() ?: return null
        return Conn(p, addr(f[1]), addr(f[2]), states[f[3]] ?: f[3], uid, f[9].toLongOrNull() ?: 0L)
    }

    private fun addr(s: String): String {
        val h = s.substringBefore(':')
        val port = s.substringAfter(':').toInt(16)
        if (h.length == 8) {
            return (3 downTo 0).joinToString(".") { h.substring(2 * it, 2 * it + 2).toInt(16).toString() } + ":$port"
        }
        val hx = (0 until 4).flatMap { g ->
            val w = h.substring(8 * g, 8 * g + 8)
            val be = w.substring(6, 8) + w.substring(4, 6) + w.substring(2, 4) + w.substring(0, 2)
            listOf(be.substring(0, 4), be.substring(4, 8))
        }
        if (hx.take(5).all { it == "0000" } && hx[5].uppercase() == "FFFF") {
            val b = hx[6] + hx[7]
            return (0 until 4).joinToString(".") { b.substring(2 * it, 2 * it + 2).toInt(16).toString() } + ":$port"
        }
        if (hx.all { it == "0000" }) return "[::]:$port"
        return "[" + hx.joinToString(":") { it.trimStart('0').ifEmpty { "0" }.lowercase() } + "]:$port"
    }
}
