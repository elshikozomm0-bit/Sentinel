package dev.sentinel

data class Conn(val proto: String, val remote: String, val state: String, val uid: Int)

object NetMonitor {
    private val states = mapOf("01" to "ESTABLISHED", "02" to "SYN_SENT", "06" to "TIME_WAIT", "08" to "CLOSE_WAIT", "0A" to "LISTEN")

    /** One snapshot of all sockets with their owning UID, read from /proc/net. */
    fun snapshot(): List<Conn> = listOf("tcp", "tcp6", "udp", "udp6").flatMap { p ->
        Root.run("cat /proc/net/$p").drop(1).mapNotNull { parse(p, it) }
    }

    private fun parse(p: String, line: String): Conn? {
        val f = line.trim().split(Regex("\\s+"))
        if (f.size < 8) return null
        val uid = f[7].toIntOrNull() ?: return null
        return Conn(p, addr(f[2]), states[f[3]] ?: f[3], uid)
    }

    private fun addr(s: String): String {
        val (h, pt) = s.split(":")
        val port = pt.toInt(16)
        val ip = if (h.length == 8) {
            (0 until 4).joinToString(".") { h.substring(6 - 2 * it, 8 - 2 * it).toInt(16).toString() }
        } else {
            (0 until 4).joinToString(":") { g ->
                val w = h.substring(8 * g, 8 * g + 8)
                val be = w.substring(6, 8) + w.substring(4, 6) + w.substring(2, 4) + w.substring(0, 2)
                be.substring(0, 4).trimStart('0').ifEmpty { "0" } + ":" + be.substring(4).trimStart('0').ifEmpty { "0" }
            }
        }
        return "$ip:$port"
    }
}
