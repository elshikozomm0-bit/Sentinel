package dev.sentinel

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val f = File(filesDir, "crash.txt")
        val prev = if (f.exists()) f.readText() else null
        f.delete()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { f.writeText(e.stackTraceToString().take(3000)) } catch (_: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        Engine.start(application)
        try { startForegroundService(Intent(this, MonitorService::class.java)) } catch (_: Throwable) {}
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { AppRoot(prev) } } }
    }
}

// ---------- small helpers ----------
private fun impAr(i: Importance) = when (i) { Importance.CORE -> "أساسي"; Importance.SYSTEM -> "نظام"; Importance.USER -> "تطبيق" }
private fun verdictAr(v: Verdict) = when (v) {
    Verdict.UNKNOWN -> "جديد"; Verdict.TRIAL -> "قيد التجربة"; Verdict.SAFE -> "آمن للإيقاف"
    Verdict.REMOVABLE -> "قابل للإزالة"; Verdict.ESSENTIAL -> "ضروري"; Verdict.PROTECTED -> "محمي"
}
private fun verdictColor(v: Verdict) = when (v) {
    Verdict.SAFE -> Color(0xFF2E7D32); Verdict.REMOVABLE -> Color(0xFFEF6C00); Verdict.ESSENTIAL -> Color(0xFFC62828)
    Verdict.PROTECTED -> Color(0xFF1565C0); else -> Color.Gray
}
private val kindAr = mapOf("START" to "بدأ", "STOP" to "توقف", "NEW_PORT" to "بورت غير معتاد", "RULE" to "قاعدة", "USER" to "أنت", "AI" to "الذكاء")

@Composable
fun Choice(text: String, selected: Boolean, onClick: () -> Unit) {
    val pad = PaddingValues(horizontal = 12.dp)
    if (selected) Button(onClick, contentPadding = pad) { Text(text, fontSize = 12.sp) }
    else OutlinedButton(onClick, contentPadding = pad) { Text(text, fontSize = 12.sp) }
}

@Composable
fun Sec(t: String) = Text(t, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 10.dp))

@Composable
fun ActRow(title: String, hint: String, enabled: Boolean = true, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        FilledTonalButton(onClick, modifier = Modifier.width(140.dp), enabled = enabled) { Text(title, fontSize = 13.sp) }
        Spacer(Modifier.width(8.dp))
        Text(hint, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
    }
}

// ---------- root ----------
@Composable
fun AppRoot(prevCrash: String?) {
    var tab by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<Int?>(null) }
    BackHandler(sel != null) { sel = null }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Text("Sentinel", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        val err = Engine.error ?: prevCrash?.let { "آخر كراش: $it" }
        if (err != null) SelectionContainer { Text(err, color = Color.Red, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 16.dp)) }
        val root = Engine.root
        if (root == null) Text("جارٍ البدء…", Modifier.padding(16.dp))
        else if (!root) Text("بانتظار صلاحية الروت: امنحها من KernelSU ثم أعد فتح التطبيق.", Modifier.padding(16.dp))
        val mem = Engine.snap.mem
        if (mem.totalMb > 0) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                val used = mem.totalMb - mem.availMb
                Text(
                    "الرام: ${used}MB من ${mem.totalMb}MB · المتاح ${mem.availMb}MB" +
                        (if (mem.swapTotalMb > 0) " · سواب ${mem.swapTotalMb - mem.swapFreeMb}MB" else "") +
                        (if (Engine.saved > 0) " · وفّر الذكاء ${Engine.saved}MB" else ""),
                    style = MaterialTheme.typography.bodySmall
                )
                LinearProgressIndicator(progress = { (used.toFloat() / mem.totalMb).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
            }
        }
        val open = sel
        if (open != null) {
            TextButton({ sel = null }) { Text("→ رجوع") }
            DetailScreen(open)
        } else {
            TabRow(selectedTabIndex = tab) {
                listOf("التطبيقات", "السجل", "الذكاء", "القواعد").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) })
                }
            }
            when (tab) {
                0 -> AppsTab { sel = it }
                1 -> TimelineTab()
                2 -> AiTab()
                else -> RulesTab()
            }
        }
    }
}

// ---------- apps ----------
@Composable
fun AppsTab(onOpen: (Int) -> Unit) {
    var filter by remember { mutableIntStateOf(0) }
    val all = Engine.snap.rows
    val rows = when (filter) {
        1 -> all.filter { it.importance == Importance.USER }
        2 -> all.filter { it.importance == Importance.SYSTEM }
        3 -> all.filter { it.importance == Importance.CORE }
        else -> all
    }
    val maxRss = (all.maxOfOrNull { it.rssMb } ?: 1L).coerceAtLeast(1L)
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Choice("الكل", filter == 0) { filter = 0 }
                Choice("تطبيقاتي", filter == 1) { filter = 1 }
                Choice("النظام", filter == 2) { filter = 2 }
                Choice("أساسية", filter == 3) { filter = 3 }
                OutlinedButton({ Engine.act { it.resort() } }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("ترتيب بالرام الآن", fontSize = 12.sp) }
            }
            Text("الترتيب ثابت: تتغير الأرقام فقط كل 5 ثوانٍ.", style = MaterialTheme.typography.labelSmall)
        }
        items(rows, key = { it.uid }) { r ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(r.uid) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(r.pkgs.firstOrNull()?.pkg, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                        val ext = r.conns.count { !it.loopback }
                        Text(
                            "${impAr(r.importance)} · الرام ${r.rssMb}MB · المعالج ${"%.1f".format(r.cpu)}% · اتصالات $ext" + if (r.blocked) " · بلا إنترنت" else "",
                            style = MaterialTheme.typography.bodySmall
                        )
                        LinearProgressIndicator(progress = { (r.rssMb.toFloat() / maxRss).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

// ---------- detail ----------
@Composable
fun DetailScreen(uid: Int) {
    val snap = Engine.snap
    val r = snap.rows.firstOrNull { it.uid == uid }
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    if (r == null) { Text("لا عمليات أو اتصالات نشطة لهذا التطبيق الآن.", Modifier.padding(16.dp)); return }
    val procMap = snap.procs
    val core = r.importance == Importance.CORE
    val one = r.pkgs.size == 1
    val detail by produceState<Detail?>(null, uid) {
        value = withContext(Dispatchers.IO) { Dumpsys.detailFor(r.pkgs.take(4).map { it.pkg }, r.procs.map { it.ppid }) }
    }
    val d = detail
    val learnedRow = Engine.learned.firstOrNull { it.pkg == r.pkgs.firstOrNull()?.pkg }
    val why = buildList {
        add(when (r.importance) {
            Importance.CORE -> "أساسي: مكوّن نظام أو دائم (uid ${r.uid}). إيقافه أو قتله قد يعطّل الجهاز."
            Importance.SYSTEM -> "نظام: تطبيق مثبّت مسبقًا. قطع شبكته غالبًا آمن، أما قتله فقد لا يكون."
            Importance.USER -> "تطبيقك: مثبّت من طرفك، آمن للتحكم."
        })
        if (r.pkgs.size > 1) add("يشارك uid واحدًا مع ${r.pkgs.size} حزمة: تعمل وتموت معًا.")
        if (d == null) add("أفحص الخدمات المرتبطة…")
        else {
            if (d.parents.isNotEmpty())
                add("شغّله: ${d.parents.joinToString()}" + if (d.parents.any { it.startsWith("zygote") }) " (عملية تطبيق عادية)" else " (خدمة نظام/أصلية)")
            if (d.clients.isEmpty()) add("لا مكوّن مرتبط بخدماته حاليًا ← مستقل.")
            else add("مكوّنات أخرى مرتبطة به ← غير مستقل: ${d.clients.take(8).joinToString()}")
        }
        if (learnedRow != null) add("حكم الذكاء: ${verdictAr(learnedRow.verdict)} (تجارب ${learnedRow.trims}، وفّر ${learnedRow.savedMb}MB)")
    }
    val ext = r.conns.filter { !it.loopback }.sortedBy { it.remote }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(r.pkgs.firstOrNull()?.pkg, 56.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(r.label, style = MaterialTheme.typography.titleMedium)
                    Text("uid ${r.uid} · ${impAr(r.importance)}" + if (r.blocked) " · بلا إنترنت" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    why.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item {
            val pids = r.procs.map { it.pid }
            val doBlock: () -> Unit = { Engine.act { m -> m.toggleBlock(uid, r.label) } }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ActRow(
                    if (r.blocked) "إعادة الإنترنت" else "قطع الإنترنت",
                    if (r.blocked) "يسمح له بالاتصال من جديد." else "يمنعه من الشبكة (واي‑فاي وبيانات) ويبقى شغالًا."
                ) {
                    if (core && !r.blocked) confirm = "مكوّن أساسي: قطع شبكته قد يعطّل المكالمات أو البيانات أو الإشعارات. يمكنك التراجع." to doBlock
                    else doBlock()
                }
                ActRow("تنظيف الذاكرة", "يغلق عملياته الخلفية بأمان لتحرير الرام، وقد يعيد نفسه.", enabled = !core && one) {
                    Engine.act { m -> m.userAction(uid, r.label, "تنظيف الذاكرة") { Controller.softKill(r.pkgs[0].pkg) } }
                }
                ActRow("إيقاف مؤقت", "يجمّده في مكانه: بلا معالج ولا استجابة، والرام تبقى محجوزة.", enabled = !core) {
                    Engine.act { m -> m.userAction(uid, r.label, "إيقاف مؤقت") { pids.forEach { Controller.freeze(it) } } }
                }
                ActRow("استئناف", "يكمل من حيث تجمّد.", enabled = !core) {
                    Engine.act { m -> m.userAction(uid, r.label, "استئناف") { pids.forEach { Controller.resume(it) } } }
                }
                ActRow("إنهاء فوري", "يقتل عملياته فورًا بلا حفظ، وقد يُعاد تشغيله.", enabled = !core) {
                    Engine.act { m -> m.userAction(uid, r.label, "إنهاء فوري") { pids.forEach { Controller.kill(it) } } }
                }
                ActRow("فرض الإيقاف", "مثل Force Stop: يلغي منبّهاته ومهامه فلا يعمل حتى تفتحه.", enabled = !core) {
                    Engine.act { m -> m.userAction(uid, r.label, "فرض الإيقاف") { r.pkgs.forEach { Controller.forceStop(it.pkg) } } }
                }
                ActRow("تعطيل التطبيق", "يخفيه ويوقفه تمامًا حتى تعيد تفعيله من تبويب الذكاء.", enabled = !core && one) {
                    confirm = "سيُعطَّل ${r.label} بالكامل ويختفي. يمكنك إعادة تفعيله من تبويب الذكاء." to
                        { Engine.act { m -> m.disableApp(r.pkgs[0].pkg, r.label) } }
                }
                if (core) Text("المكوّنات الأساسية: لا يُتاح لها إلا قطع الإنترنت (بتأكيد).", style = MaterialTheme.typography.labelSmall)
            }
        }
        item { Sec("الحزم (${r.pkgs.size})") }
        items(r.pkgs, key = { it.pkg }) { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(p.pkg, 32.dp)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(p.label, style = MaterialTheme.typography.bodyMedium)
                    Text(p.pkg + if (p.system) " · نظام" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (d != null && d.services.isNotEmpty()) {
            item { Sec("الخدمات الشغالة (${d.services.size})") }
            items(d.services.take(40), key = { it.name }) { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(s.name.substringBefore('/'), 28.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(s.name.substringAfter('/') + if (s.foreground) " · أمامية" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Sec("العمليات (${r.procs.size})") }
        items(r.procs.sortedWith(compareBy({ it.name }, { it.pid })), key = { it.pid }) { p ->
            Text("${p.name} · pid ${p.pid} · ${lineage(procMap[p.ppid], procMap)} · ${p.rssKb / 1024}MB · ${"%.1f".format(p.cpu)}%",
                style = MaterialTheme.typography.bodySmall)
        }
        item { Sec("الاتصالات (${ext.size} خارجي، ${r.conns.size - ext.size} محلي)") }
        items(ext.take(80)) { c ->
            Column {
                Text("${c.proto} ${c.remote}  ${portLabel(c.remote)}", style = MaterialTheme.typography.bodyMedium)
                val owner = procMap[c.pid]
                Text(
                    "${c.state} · " + (if (owner != null) "pid ${c.pid} ${owner.name} ← ${lineage(procMap[owner.ppid], procMap)}"
                    else if (c.inode == 0L) "قيد الإغلاق (بلا مالك)" else "المالك غير معروف"),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    confirm?.let { (msg, action) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("تأكيد") },
            text = { Text(msg) },
            confirmButton = { TextButton({ confirm = null; action() }) { Text("متابعة") } },
            dismissButton = { TextButton({ confirm = null }) { Text("إلغاء") } }
        )
    }
}

// ---------- timeline ----------
@Composable
fun TimelineTab() {
    val ev = Engine.events
    val rows = Engine.snap.rows
    val fmt = remember { java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US) }
    if (ev.isEmpty()) Text("لا أحداث بعد. ستظهر هنا بدايات التطبيقات وإيقافها والبورتات غير المعتادة وقرارات الذكاء والقواعد.", Modifier.padding(16.dp))
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(ev, key = { it.id }) { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(rows.firstOrNull { it.uid == e.uid }?.pkgs?.firstOrNull()?.pkg, 32.dp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("${e.label} · ${kindAr[e.kind] ?: e.kind}", style = MaterialTheme.typography.bodyMedium)
                    Text(e.detail, style = MaterialTheme.typography.bodySmall)
                    Text(fmt.format(Date(e.ts)), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

// ---------- smart manager ----------
@Composable
fun AiTab() {
    val learned = Engine.learned
    val mode = Engine.aiMode
    var confirm by remember { mutableStateOf<Learned?>(null) }
    val groups = listOf(Verdict.REMOVABLE, Verdict.SAFE, Verdict.TRIAL, Verdict.ESSENTIAL, Verdict.PROTECTED)
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("المدير الذكي", style = MaterialTheme.typography.titleMedium)
            Text(
                "يراقب التطبيقات والخدمات الخلفية، يجرّب تنظيف الثقيل منها بأمان، ثم يراقب رد فعل النظام (أعطال، تعليق، إعادة تشغيل). " +
                    "ما لا يؤثر يصنّفه آمنًا ثم قابلًا للإزالة، وما يؤثر يتراجع عنه ويصنّفه ضروريًا.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Choice("متوقف", mode == AiMode.OFF) { Engine.setMode(AiMode.OFF) }
                Choice("آمن", mode == AiMode.SAFE) { Engine.setMode(AiMode.SAFE) }
                Choice("ذكي", mode == AiMode.SMART) { Engine.setMode(AiMode.SMART) }
            }
            Text(
                when (mode) {
                    AiMode.OFF -> "لا يفعل شيئًا."
                    AiMode.SAFE -> "تطبيقاتك فقط، تنظيف آمن للذاكرة (لا يمنع الإشعارات)."
                    AiMode.SMART -> "+ تطبيقات النظام غير الأساسية، وتقييد الخلفية لمن يعيد تشغيل نفسه."
                },
                style = MaterialTheme.typography.labelSmall
            )
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("الحالة: ${Engine.aiStatus}", style = MaterialTheme.typography.bodyMedium)
                    Text("وفّر إجمالًا: ${Engine.saved}MB · تطبيقات متعلَّمة: ${learned.size}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        for (g in groups) {
            val list = learned.filter { it.verdict == g }
            if (list.isEmpty()) continue
            item(key = "h-${g.name}") { Sec("${verdictAr(g)} (${list.size})") }
            items(list, key = { it.pkg }) { l ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(l.pkg, 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(l.label, style = MaterialTheme.typography.bodyMedium)
                        Text("تنظيفات ${l.trims} · وفّر ${l.savedMb}MB · عاد ${l.respawns} مرة" + if (l.restricted) " · الخلفية مقيّدة" else "",
                            style = MaterialTheme.typography.bodySmall, color = verdictColor(l.verdict))
                    }
                    Column {
                        if (g == Verdict.PROTECTED || g == Verdict.ESSENTIAL)
                            TextButton({ Engine.setVerdict(l.pkg, Verdict.UNKNOWN) }) { Text("إعادة للتعلّم", fontSize = 11.sp) }
                        else TextButton({ Engine.setVerdict(l.pkg, Verdict.PROTECTED) }) { Text("حماية", fontSize = 11.sp) }
                        if (g == Verdict.REMOVABLE) TextButton({ confirm = l }) { Text("تعطيل", fontSize = 11.sp) }
                    }
                }
            }
        }
        if (Engine.disabledApps.isNotEmpty()) {
            item { Sec("تطبيقات عطّلتها (${Engine.disabledApps.size})") }
            items(Engine.disabledApps, key = { it.first }) { (pkg, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(pkg, 32.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    TextButton({ Engine.act { m -> m.enableApp(pkg) } }) { Text("تفعيل") }
                }
            }
        }
    }
    confirm?.let { l ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("تعطيل ${l.label}؟") },
            text = { Text("صنّفه الذكاء قابلًا للإزالة. سيُعطَّل ويختفي، ويمكنك إعادة تفعيله من هنا.") },
            confirmButton = { TextButton({ confirm = null; Engine.act { m -> m.disableApp(l.pkg, l.label) } }) { Text("تعطيل") } },
            dismissButton = { TextButton({ confirm = null }) { Text("إلغاء") } }
        )
    }
}

// ---------- rules ----------
@Composable
fun RulesTab() {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("القواعد لا تعمل إلا على تطبيقاتك، ولا تلمس المكوّنات المحمية (الكيبورد، اللانشر، المكالمات، خدمات جوجل…). حظر القواعد يُرفع لو أُعيد تشغيل Sentinel.", style = MaterialTheme.typography.bodySmall) }
        items(Preset.values().toList(), key = { it.key }) { p ->
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.title, style = MaterialTheme.typography.titleSmall)
                        Text(p.desc, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = p.key in Engine.presets, onCheckedChange = { on -> Engine.setPreset(p.key, on) })
                }
                if (p == Preset.RAM_CAP) {
                    var v by remember(Engine.ramCap) { mutableFloatStateOf(Engine.ramCap.toFloat()) }
                    Text("الحد: ${v.toInt()}MB", style = MaterialTheme.typography.labelSmall)
                    Slider(value = v, onValueChange = { v = it }, onValueChangeFinished = { Engine.updateRamCap(v.toInt()) }, valueRange = 100f..1500f)
                }
            }
        }
        item { TextButton({ Engine.act { m -> m.unblockAll() } }) { Text("إزالة كل حظر الإنترنت") } }
    }
}
