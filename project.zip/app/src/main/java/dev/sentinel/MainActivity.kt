package dev.sentinel

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val f = File(filesDir, "crash.txt")
        val prev = if (f.exists()) f.readText() else null
        f.delete()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { f.writeText(e.stackTraceToString().take(3000)) } catch (_: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        Engine.start(application)
        try { startForegroundService(Intent(this, MonitorService::class.java)) } catch (_: Throwable) {}
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { AppRoot(prev) } } }
    }
}

@Composable
fun AppRoot(prevCrash: String?) {
    var tab by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<Int?>(null) }
    BackHandler(sel != null) { sel = null }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Text("Sentinel", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        val err = Engine.error ?: prevCrash?.let { "previous crash: $it" }
        if (err != null) SelectionContainer { Text(err, color = Color.Red, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 16.dp)) }
        val root = Engine.root
        if (root == null) Text("Starting…", Modifier.padding(16.dp))
        else if (!root) Text("Waiting for root — grant it in KernelSU, then reopen.", Modifier.padding(16.dp))
        val open = sel
        if (open != null) {
            TextButton({ sel = null }) { Text("← Back") }
            DetailScreen(open)
        } else {
            TabRow(selectedTabIndex = tab) {
                listOf("Apps", "Timeline", "Rules").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            when (tab) {
                0 -> AppsTab { sel = it }
                1 -> TimelineTab()
                else -> RulesTab()
            }
        }
    }
}

@Composable
fun AppsTab(onOpen: (Int) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Engine.snap.rows, key = { it.uid }) { r ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(r.uid) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(r.pkgs.firstOrNull()?.pkg, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                        val ext = r.conns.count { !it.loopback }
                        Text(
                            "${r.importance} · conns $ext · RAM ${r.rssMb}MB · CPU ${"%.1f".format(r.cpu)}%" + if (r.blocked) " · BLOCKED" else "",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Sec(t: String) = Text(t, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 10.dp))

@Composable
fun DetailScreen(uid: Int) {
    val snap = Engine.snap
    val r = snap.rows.firstOrNull { it.uid == uid }
    var confirm by remember { mutableStateOf<String?>(null) }
    if (r == null) { Text("This app has no active processes or connections right now.", Modifier.padding(16.dp)); return }
    val procMap = snap.procs
    val core = r.importance == Importance.CORE
    val detail by produceState<Detail?>(null, uid) {
        value = withContext(Dispatchers.IO) { Dumpsys.detailFor(r.pkgs.take(4).map { it.pkg }, r.procs.map { it.ppid }) }
    }
    val d = detail
    val why = buildList {
        add(when (r.importance) {
            Importance.CORE -> "CORE: system or persistent component (uid ${r.uid}). Freezing or killing it can break the phone."
            Importance.SYSTEM -> "SYSTEM: preinstalled app. Restricting its network is usually safe; killing it may not be."
            Importance.USER -> "USER: installed by you. Safe to control."
        })
        if (r.pkgs.size > 1) add("Shares one uid with ${r.pkgs.size} packages: they run and die together.")
        if (d == null) add("Checking bound services…")
        else {
            if (d.parents.isNotEmpty())
                add("Started by: ${d.parents.joinToString()}" + if (d.parents.any { it.startsWith("zygote") }) " (normal app process)" else " (native/system launched)")
            if (d.clients.isEmpty()) add("No other component is bound to its services right now → standalone.")
            else add("Other components are bound to it → NOT standalone: ${d.clients.take(8).joinToString()}")
        }
    }
    val ext = r.conns.filter { !it.loopback }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(r.pkgs.firstOrNull()?.pkg, 56.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(r.label, style = MaterialTheme.typography.titleMedium)
                    Text("uid ${r.uid} · ${r.importance}" + if (r.blocked) " · BLOCKED" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    why.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item {
            val pids = r.procs.map { it.pid }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                TextButton({
                    if (core) confirm = "This is a core component. Blocking its network can break calls, data or push. You can undo it with Unblock."
                    else Engine.act { m -> m.toggleBlock(uid, r.label) }
                }) { Text(if (r.blocked) "Unblock" else "Block") }
                TextButton({ Engine.act { m -> m.userAction(uid, r.label, "frozen") { pids.forEach { Controller.freeze(it) } } } }, enabled = !core) { Text("Freeze") }
                TextButton({ Engine.act { m -> m.userAction(uid, r.label, "resumed") { pids.forEach { Controller.resume(it) } } } }, enabled = !core) { Text("Resume") }
                TextButton({ Engine.act { m -> m.userAction(uid, r.label, "killed") { pids.forEach { Controller.kill(it) } } } }, enabled = !core) { Text("Kill") }
                TextButton({ Engine.act { m -> m.userAction(uid, r.label, "force-stopped") { r.pkgs.forEach { Controller.forceStop(it.pkg) } } } }, enabled = !core) { Text("Stop") }
            }
        }
        item { Sec("Packages (${r.pkgs.size})") }
        items(r.pkgs, key = { it.pkg }) { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(p.pkg, 32.dp)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(p.label, style = MaterialTheme.typography.bodyMedium)
                    Text(p.pkg + if (p.system) " · system" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (d != null && d.services.isNotEmpty()) {
            item { Sec("Running services (${d.services.size})") }
            items(d.services.take(40), key = { it.name }) { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(s.name.substringBefore('/'), 28.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(s.name.substringAfter('/') + if (s.foreground) " · foreground" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Sec("Processes (${r.procs.size})") }
        items(r.procs.sortedByDescending { it.cpu }, key = { it.pid }) { p ->
            Text("${p.name} · pid ${p.pid} · ${lineage(procMap[p.ppid], procMap)} · ${p.rssKb / 1024}MB · ${"%.1f".format(p.cpu)}%",
                style = MaterialTheme.typography.bodySmall)
        }
        item { Sec("Connections (${ext.size} external, ${r.conns.size - ext.size} local)") }
        items(ext.take(80)) { c ->
            Column {
                Text("${c.proto} ${c.remote}  ${portLabel(c.remote)}", style = MaterialTheme.typography.bodyMedium)
                val owner = procMap[c.pid]
                Text(
                    "${c.state} · " + (if (owner != null) "pid ${c.pid} ${owner.name} ← ${lineage(procMap[owner.ppid], procMap)}"
                    else if (c.inode == 0L) "closing (no owner)" else "owner not found"),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    confirm?.let { msg ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Core component") },
            text = { Text(msg) },
            confirmButton = { TextButton({ confirm = null; Engine.act { m -> m.toggleBlock(uid, r.label) } }) { Text("Proceed") } },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun TimelineTab() {
    val ev = Engine.events
    val rows = Engine.snap.rows
    val fmt = remember { java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US) }
    if (ev.isEmpty()) Text("No events yet. Events appear as apps start, stop, open unusual ports, or rules fire.", Modifier.padding(16.dp))
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(ev, key = { it.id }) { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(rows.firstOrNull { it.uid == e.uid }?.pkgs?.firstOrNull()?.pkg, 32.dp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("${e.label} · ${e.kind}", style = MaterialTheme.typography.bodyMedium)
                    Text(e.detail, style = MaterialTheme.typography.bodySmall)
                    Text(fmt.format(Date(e.ts)), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun RulesTab() {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Rules only ever act on user-installed apps, never on core system components. Rule-based blocks are lifted if Sentinel restarts.", style = MaterialTheme.typography.bodySmall) }
        items(Preset.values().toList(), key = { it.key }) { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.title, style = MaterialTheme.typography.titleSmall)
                    Text(p.desc, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = p.key in Engine.presets, onCheckedChange = { on -> Engine.setPreset(p.key, on) })
            }
        }
        item { TextButton({ Engine.act { m -> m.unblockAll() } }) { Text("Unblock everything") } }
    }
}
