package dev.sentinel

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*
import java.io.File

data class AppRow(val uid: Int, val label: String, val conns: Int, val remotes: List<String>,
                  val rssMb: Long, val cpu: Double, val pids: List<Int>, val pkg: String?)

class VM(app: Application) : AndroidViewModel(app) {
    var rows by mutableStateOf(listOf<AppRow>()); private set
    var root by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                Root.init(); root = Root.hasRoot()
                if (root) Controller.setup()
            } catch (e: Throwable) { error = "init: " + e.stackTraceToString().take(1500) }
            if (!root) return@launch
            val pm = getApplication<Application>().packageManager
            while (isActive) {
                try {
                    val conns = NetMonitor.snapshot().filter { it.state != "LISTEN" && !it.remote.startsWith("0.0.0.0") }
                    val procs = ProcMonitor.processes(); val cpu = ProcMonitor.cpuByPid()
                    val uids = (conns.map { it.uid } + procs.map { it.uid }).toSet()
                    rows = uids.map { uid ->
                        val pkgs = try { pm.getPackagesForUid(uid) } catch (e: Exception) { null }
                        val c = conns.filter { it.uid == uid }; val p = procs.filter { it.uid == uid }
                        AppRow(uid, pkgs?.firstOrNull() ?: "uid:$uid", c.size, c.map { it.remote }.distinct().take(5),
                            p.sumOf { it.rssKb } / 1024, p.sumOf { cpu[it.pid] ?: 0.0 }, p.map { it.pid }, pkgs?.firstOrNull())
                    }.sortedByDescending { it.conns * 10 + it.cpu }
                    error = null
                } catch (e: CancellationException) { throw e
                } catch (e: Exception) { error = "loop: " + e.stackTraceToString().take(1500) }
                delay(3000)
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val f = File(filesDir, "crash.txt")
        val prev = if (f.exists()) f.readText() else null
        f.delete()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { f.writeText(e.stackTraceToString().take(3000)) } catch (_: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen(prev) } } }
    }
}

@Composable
fun Screen(prevCrash: String?, vm: VM = viewModel()) {
    LazyColumn(
        Modifier.statusBarsPadding().navigationBarsPadding().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Sentinel", style = MaterialTheme.typography.headlineSmall) }
        val err = vm.error ?: prevCrash?.let { "previous crash: $it" }
        if (err != null) item { SelectionContainer { Text(err, color = Color.Red, fontSize = 10.sp) } }
        if (!vm.root) item { Text("Waiting for root (grant in KernelSU)…") }
        items(vm.rows, key = { it.uid }) { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(r.label, style = MaterialTheme.typography.titleSmall)
                    Text("conns ${r.conns} · RAM ${r.rssMb}MB · CPU ${"%.1f".format(r.cpu)}%")
                    if (r.remotes.isNotEmpty()) Text(r.remotes.joinToString(), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton({ Thread { Controller.block(r.uid) }.start() }) { Text("Block") }
                        TextButton({ Thread { r.pids.forEach { Controller.freeze(it) } }.start() }) { Text("Freeze") }
                        TextButton({ Thread { r.pids.forEach { Controller.resume(it) } }.start() }) { Text("Resume") }
                        TextButton({ Thread { r.pkg?.let { Controller.forceStop(it) } }.start() }) { Text("Stop") }
                    }
                }
            }
        }
        item { TextButton({ Thread { Controller.unblockAll() }.start() }) { Text("Unblock all") }; Spacer(Modifier.height(24.dp)) }
    }
}
