package dev.sentinel

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*

data class AppRow(val uid: Int, val label: String, val conns: Int, val remotes: List<String>,
                  val rssMb: Long, val cpu: Double, val pids: List<Int>, val pkg: String?)

class VM(app: Application) : AndroidViewModel(app) {
    var rows by mutableStateOf(listOf<AppRow>()); private set
    var root by mutableStateOf(false); private set

    init {
        viewModelScope.launch(Dispatchers.IO) {
            Root.init(); root = Root.hasRoot()
            if (!root) return@launch
            Controller.setup()
            val pm = getApplication<Application>().packageManager
            while (isActive) {
                val conns = NetMonitor.snapshot().filter { it.state != "LISTEN" && !it.remote.startsWith("0.0.0.0") }
                val procs = ProcMonitor.processes(); val cpu = ProcMonitor.cpuByPid()
                val uids = (conns.map { it.uid } + procs.map { it.uid }).toSet()
                rows = uids.map { uid ->
                    val pkgs = pm.getPackagesForUid(uid)
                    val c = conns.filter { it.uid == uid }; val p = procs.filter { it.uid == uid }
                    AppRow(uid, pkgs?.firstOrNull() ?: "uid:$uid", c.size, c.map { it.remote }.distinct().take(5),
                        p.sumOf { it.rssKb } / 1024, p.sumOf { cpu[it.pid] ?: 0.0 }, p.map { it.pid }, pkgs?.firstOrNull())
                }.sortedByDescending { it.conns * 10 + it.cpu }
                delay(3000)
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } } }
    }
}

@Composable
fun Screen(vm: VM = viewModel()) {
    if (!vm.root) { Text("Waiting for root (grant in KernelSU)…", Modifier.padding(24.dp)); return }
    LazyColumn(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Spacer(Modifier.height(32.dp)); Text("Sentinel", style = MaterialTheme.typography.headlineSmall) }
        items(vm.rows, key = { it.uid }) { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(r.label, style = MaterialTheme.typography.titleSmall)
                    Text("conns ${r.conns} · RAM ${r.rssMb}MB · CPU ${"%.1f".format(r.cpu)}%")
                    if (r.remotes.isNotEmpty()) Text(r.remotes.joinToString(), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton({ Controller.block(r.uid) }) { Text("Block") }
                        TextButton({ r.pids.forEach(Controller::freeze) }) { Text("Freeze") }
                        TextButton({ r.pids.forEach(Controller::resume) }) { Text("Resume") }
                        TextButton({ r.pkg?.let(Controller::forceStop) }) { Text("Stop") }
                    }
                }
            }
        }
        item { TextButton({ Controller.unblockAll() }) { Text("Unblock all") }; Spacer(Modifier.height(24.dp)) }
    }
}
