package dev.sentinel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*

/** Process-wide monitoring loop. Kept alive by MonitorService; the UI only reads its state. */
object Engine {
    var snap by mutableStateOf(Snapshot(emptyList(), emptyMap())); private set
    var events by mutableStateOf(listOf<Event>()); private set
    var presets by mutableStateOf(setOf<String>()); private set
    var root by mutableStateOf<Boolean?>(null); private set
    var error by mutableStateOf<String?>(null); private set
    @Volatile var monitor: Monitor? = null; private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    @Synchronized
    fun start(app: Application) {
        if (job?.isActive == true) return
        job = scope.launch {
            try {
                Root.init()
                val ok = Root.hasRoot()
                root = ok
                if (!ok) return@launch
                val store = Store(app)
                val m = Monitor(app, store)
                m.start()
                monitor = m
                presets = m.enabled.toSet()
                while (isActive) {
                    try {
                        snap = m.cycle()
                        events = store.recentEvents(300)
                        error = null
                    } catch (e: CancellationException) { throw e
                    } catch (e: Exception) { error = "loop: " + e.stackTraceToString().take(1500) }
                    delay(5000)
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Throwable) { error = "init: " + e.stackTraceToString().take(1500) }
        }
    }

    fun act(f: (Monitor) -> Unit) {
        scope.launch {
            try { monitor?.let(f) } catch (e: Exception) { error = "action: " + e.stackTraceToString().take(800) }
        }
    }

    fun setPreset(key: String, on: Boolean) = act { m -> m.setPreset(key, on); presets = m.enabled.toSet() }
}
