package dev.sentinel

import android.app.Application
import android.content.pm.ApplicationInfo
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

class Monitor(private val app: Application, private val store: Store) {
    private val pm = app.packageManager
    private val selfUid = app.applicationInfo.uid
    private val known = HashSet<String>(store.loadDests())
    private val firstRun: Long = store.setting("first_run")?.toLongOrNull()
        ?: System.currentTimeMillis().also { store.setSetting("first_run", it.toString()) }

    private val blocked: MutableSet<Int> = ConcurrentHashMap.newKeySet<Int>().also { it.addAll(store.blocks()) }
    private val ruleBlocked: MutableSet<Int> = ConcurrentHashMap.newKeySet<Int>()
    private val nightBlocked: MutableSet<Int> = ConcurrentHashMap.newKeySet<Int>()
    val enabled: MutableSet<String> = ConcurrentHashMap.newKeySet<String>().also { s ->
        Preset.values().filter { store.setting("rule:" + it.key) == "1" }.forEach { s.add(it.key) }
    }

    private val pkgCache = ConcurrentHashMap<Int, List<PkgInfo>>()
    private val labels = HashMap<Int, String>()
    private val cpuHigh = HashMap<Int, Int>()
    private var prevAlive: Set<Int>? = null

    private val nativeNames = mapOf(
        0 to "root (native services)", 1000 to "Android system", 1001 to "radio / telephony", 1002 to "bluetooth",
        1013 to "mediaserver", 1017 to "keystore", 1036 to "logd", 2000 to "adb shell"
    )
    private val common = setOf("443", "80", "53", "123", "853", "5228")

    fun start() {
        Controller.setup()
        Controller.unblockAll()               // fail-open: rule blocks are not restored after a restart
        blocked.forEach { Controller.block(it) }
    }

    fun learning() = System.currentTimeMillis() - firstRun < 6 * 3600_000L
    fun isBlocked(uid: Int) = uid in blocked || uid in ruleBlocked || uid in nightBlocked

    // ---------- collection ----------
    fun cycle(): Snapshot {
        val procs = ProcMonitor.sample()
        val procMap = procs.associateBy { it.pid }
        val conns = NetMonitor.snapshot()
        val byC = conns.groupBy { it.uid }
        val byP = procs.groupBy { it.uid }
        val rows = (byC.keys + byP.keys).map { uid ->
            val pk = pkgs(uid)
            val c = byC[uid].orEmpty()
            val p = byP[uid].orEmpty()
            AppRow(uid, label(uid, pk), pk, importance(uid, pk), c, p,
                p.sumOf { it.rssKb } / 1024, p.sumOf { it.cpu }, isBlocked(uid))
        }.sortedByDescending { r -> r.conns.count { !it.loopback } * 10 + r.cpu }
        val newPorts = trackDests(rows, procMap)
        trackLife(rows)
        applyRules(rows, newPorts)
        return Snapshot(rows, procMap)
    }

    private fun pkgs(uid: Int): List<PkgInfo> = pkgCache.getOrPut(uid) {
        val arr: Array<String>? = try { pm.getPackagesForUid(uid) } catch (e: Exception) { null }
        (arr?.toList() ?: emptyList()).mapNotNull { p ->
            try {
                val ai = pm.getApplicationInfo(p, 0)
                PkgInfo(p, pm.getApplicationLabel(ai).toString(),
                    (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    (ai.flags and ApplicationInfo.FLAG_PERSISTENT) != 0)
            } catch (e: Exception) { null }
        }
    }

    private fun label(uid: Int, pk: List<PkgInfo>): String = when {
        pk.isEmpty() -> nativeNames[uid] ?: "uid:$uid"
        pk.size == 1 -> pk[0].label
        else -> "${pk[0].label} +${pk.size - 1}"
    }

    private fun importance(uid: Int, pk: List<PkgInfo>): Importance = when {
        uid < 10000 || pk.any { it.persistent } -> Importance.CORE
        pk.any { it.system } -> Importance.SYSTEM
        else -> Importance.USER
    }

    // ---------- baseline + timeline ----------
    private fun trackDests(rows: List<AppRow>, procs: Map<Int, Proc>): Set<Int> {
        val learn = learning()
        val newPorts = HashSet<Int>()
        val fresh = ArrayList<String>()
        for (r in rows) for (c in r.conns) {
            if (c.loopback) continue
            val ip = "${r.uid}|ip:" + c.remote.substringBeforeLast(':')
            val port = c.remote.substringAfterLast(':')
            val pk = "${r.uid}|port:${c.proto.take(3)}:$port"
            if (known.add(ip)) fresh.add(ip)
            if (known.add(pk)) {
                fresh.add(pk)
                if (!learn && port !in common && r.importance != Importance.CORE) {
                    newPorts.add(r.uid)
                    store.addEvent(r.uid, r.label, "NEW_PORT", "${c.proto} → ${c.remote} (${procs[c.pid]?.name ?: "?"})")
                }
            }
        }
        if (fresh.isNotEmpty()) store.addDests(fresh)
        return newPorts
    }

    private fun trackLife(rows: List<AppRow>) {
        val alive = rows.filter { it.procs.isNotEmpty() && it.importance == Importance.USER }.map { it.uid }.toSet()
        rows.forEach { labels[it.uid] = it.label }
        val prev = prevAlive
        if (prev != null) {
            for (u in alive - prev) store.addEvent(u, labels[u] ?: "uid:$u", "START", "process started")
            for (u in prev - alive) store.addEvent(u, labels[u] ?: "uid:$u", "STOP", "no processes left")
        }
        prevAlive = alive
    }

    // ---------- rules (only ever act on USER apps) ----------
    private fun applyRules(rows: List<AppRow>, newPorts: Set<Int>) {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        for (r in rows) {
            if (r.importance != Importance.USER || r.uid == selfUid) continue
            if (Preset.FREEZE_CPU.key in enabled) {
                if (r.cpu > 80) {
                    val n = (cpuHigh[r.uid] ?: 0) + 1
                    cpuHigh[r.uid] = n
                    if (n >= 6) {
                        r.procs.forEach { Controller.freeze(it.pid) }
                        cpuHigh.remove(r.uid)
                        store.addEvent(r.uid, r.label, "RULE", "frozen: CPU above 80% for ~30s")
                    }
                } else cpuHigh.remove(r.uid)
            }
            if (Preset.BLOCK_NEW_PORT.key in enabled && r.uid in newPorts && !isBlocked(r.uid)) {
                Controller.block(r.uid); ruleBlocked.add(r.uid)
                store.addEvent(r.uid, r.label, "RULE", "network blocked: unusual port")
            }
            if (Preset.NIGHT_BLOCK.key in enabled && hour in 1..4 && !isBlocked(r.uid) && r.conns.any { !it.loopback }) {
                Controller.block(r.uid); nightBlocked.add(r.uid)
                store.addEvent(r.uid, r.label, "RULE", "night lockdown: network blocked")
            }
        }
        if (hour !in 1..4 && nightBlocked.isNotEmpty()) {
            nightBlocked.toList().forEach { Controller.unblock(it); nightBlocked.remove(it) }
            store.addEvent(-1, "Sentinel", "RULE", "night lockdown ended")
        }
    }

    // ---------- user actions ----------
    fun toggleBlock(uid: Int, label: String) {
        if (isBlocked(uid)) {
            Controller.unblock(uid)
            blocked.remove(uid); ruleBlocked.remove(uid); nightBlocked.remove(uid)
            store.setBlocked(uid, false)
            store.addEvent(uid, label, "USER", "network unblocked")
        } else {
            Controller.block(uid)
            blocked.add(uid)
            store.setBlocked(uid, true)
            store.addEvent(uid, label, "USER", "network blocked")
        }
    }

    fun userAction(uid: Int, label: String, what: String, f: () -> Unit) {
        f()
        store.addEvent(uid, label, "USER", what)
    }

    fun setPreset(key: String, on: Boolean) {
        if (on) enabled.add(key) else enabled.remove(key)
        store.setSetting("rule:$key", if (on) "1" else "0")
        if (!on && key == Preset.NIGHT_BLOCK.key) nightBlocked.toList().forEach { Controller.unblock(it); nightBlocked.remove(it) }
        if (!on && key == Preset.BLOCK_NEW_PORT.key) ruleBlocked.toList().forEach { Controller.unblock(it); ruleBlocked.remove(it) }
    }

    fun unblockAll() {
        Controller.unblockAll()
        blocked.clear(); ruleBlocked.clear(); nightBlocked.clear()
        store.clearBlocks()
        store.addEvent(-1, "Sentinel", "USER", "all network blocks removed")
    }
}
