package dev.sentinel

enum class Importance { CORE, SYSTEM, USER }

data class Conn(
    val proto: String, val local: String, val remote: String, val state: String,
    val uid: Int, val inode: Long, val pid: Int = -1
) {
    val loopback get() = remote.startsWith("127.") || remote.startsWith("[::1]")
    val unconnected get() = remote.endsWith(":0")
}

data class Proc(val pid: Int, val ppid: Int, val uid: Int, val name: String, val rssKb: Long, val cpu: Double = 0.0)
data class PkgInfo(val pkg: String, val label: String, val system: Boolean, val persistent: Boolean)

data class AppRow(
    val uid: Int, val label: String, val pkgs: List<PkgInfo>, val importance: Importance,
    val conns: List<Conn>, val procs: List<Proc>, val rssMb: Long, val cpu: Double, val blocked: Boolean
)

data class MemInfo(val totalMb: Long, val availMb: Long, val swapTotalMb: Long, val swapFreeMb: Long)
data class Snapshot(val rows: List<AppRow>, val procs: Map<Int, Proc>, val mem: MemInfo = MemInfo(0, 0, 0, 0))
data class Event(val id: Long, val ts: Long, val uid: Int, val label: String, val kind: String, val detail: String)

enum class Preset(val key: String, val title: String, val desc: String) {
    RAM_CAP("ram_cap", "سقف الرام للتطبيقات الخلفية", "ينظّف أي تطبيق من تطبيقاتك في الخلفية يتجاوز الحد الذي تحدده (تنظيف آمن، بدون إيقاف إجباري)."),
    SCREEN_OFF_CLEAN("screen_off_clean", "تنظيف عند إطفاء الشاشة", "بعد 10 دقائق من إطفاء الشاشة ينظّف تطبيقاتك الخلفية الثقيلة مرة واحدة."),
    FREEZE_CPU("freeze_cpu", "إيقاف مستهلك المعالج", "يجمّد تطبيقك لو بقي فوق 80% معالج نحو 30 ثانية."),
    BLOCK_NEW_PORT("block_new_port", "قطع النت عند بورت غريب", "بعد فترة التعلّم (6 ساعات) يقطع إنترنت تطبيقك لو فتح بورتًا لم يستخدمه من قبل."),
    NIGHT_BLOCK("night_block", "قفل الشبكة ليلًا", "يقطع إنترنت تطبيقاتك من 1 إلى 5 فجرًا.")
}

fun portLabel(remote: String): String = when (remote.substringAfterLast(':')) {
    "443" -> "HTTPS"
    "80" -> "HTTP"
    "53" -> "DNS"
    "853" -> "DNS-over-TLS"
    "5228", "5229", "5230" -> "Google push (FCM)"
    "123" -> "NTP"
    "993", "995", "587", "465" -> "mail"
    "8883", "1883" -> "MQTT"
    else -> ""
}

fun lineage(p: Proc?, all: Map<Int, Proc>): String {
    if (p == null) return "?"
    val out = ArrayList<String>()
    var cur: Proc? = p
    var n = 0
    while (cur != null && n < 5) { out.add(cur.name); cur = all[cur.ppid]; n++ }
    return out.joinToString(" ← ")
}
