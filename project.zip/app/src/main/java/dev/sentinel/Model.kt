package dev.sentinel

enum class Importance { CORE, SYSTEM, USER }

data class Conn(
    val proto: String, val local: String, val remote: String, val state: String,
    val uid: Int, val inode: Long, val pid: Int = -1
) {
    val loopback get() = remote.startsWith("127.") || remote.startsWith("[::1]")
    val unconnected get() = remote.endsWith(":0")
}

data class Proc(val pid: Int, val ppid: Int, val uid: Int, val name: String, val rssKb: Long, val cpu: Double = 0.0)
data class PkgInfo(val pkg: String, val label: String, val system: Boolean, val persistent: Boolean)

data class AppRow(
    val uid: Int, val label: String, val pkgs: List<PkgInfo>, val importance: Importance,
    val conns: List<Conn>, val procs: List<Proc>, val rssMb: Long, val cpu: Double, val blocked: Boolean
)

data class Snapshot(val rows: List<AppRow>, val procs: Map<Int, Proc>)
data class Event(val id: Long, val ts: Long, val uid: Int, val label: String, val kind: String, val detail: String)

enum class Preset(val key: String, val title: String, val desc: String) {
    FREEZE_CPU("freeze_cpu", "Freeze CPU hogs", "Freeze a user app that stays above 80% CPU for about 30 seconds."),
    BLOCK_NEW_PORT("block_new_port", "Block on unusual port", "After the 6h learning period, block the network of a user app that opens a port it never used before."),
    NIGHT_BLOCK("night_block", "Night network lockdown", "Block the network of user apps between 01:00 and 05:00.")
}

fun portLabel(remote: String): String = when (remote.substringAfterLast(':')) {
    "443" -> "HTTPS"
    "80" -> "HTTP"
    "53" -> "DNS"
    "853" -> "DNS-over-TLS"
    "5228", "5229", "5230" -> "Google push (FCM)"
    "123" -> "NTP"
    "993", "995", "587", "465" -> "mail"
    "8883", "1883" -> "MQTT"
    else -> ""
}

fun lineage(p: Proc?, all: Map<Int, Proc>): String {
    if (p == null) return "?"
    val out = ArrayList<String>()
    var cur: Proc? = p
    var n = 0
    while (cur != null && n < 5) { out.add(cur.name); cur = all[cur.ppid]; n++ }
    return out.joinToString(" ← ")
}
