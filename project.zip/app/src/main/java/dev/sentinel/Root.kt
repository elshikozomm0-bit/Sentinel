package dev.sentinel
import com.topjohnwu.superuser.Shell

object Root {
    fun init() { Shell.setDefaultBuilder(Shell.Builder.create().setTimeout(15)) }
    fun hasRoot(): Boolean = Shell.getShell().isRoot
    fun run(cmd: String): List<String> = Shell.cmd(cmd).exec().out
    fun ok(cmd: String): Boolean = Shell.cmd(cmd).exec().isSuccess
}
