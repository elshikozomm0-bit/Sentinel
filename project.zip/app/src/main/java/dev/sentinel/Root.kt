package dev.sentinel
import com.topjohnwu.superuser.Shell

object Root {
    private var done = false
    @Synchronized fun init() {
        if (done) return
        done = true
        try { Shell.setDefaultBuilder(Shell.Builder.create().setTimeout(15)) } catch (_: Exception) {}
    }
    fun hasRoot(): Boolean = Shell.getShell().isRoot
    fun run(cmd: String): List<String> = Shell.cmd(cmd).exec().out
    fun ok(cmd: String): Boolean = Shell.cmd(cmd).exec().isSuccess
}
