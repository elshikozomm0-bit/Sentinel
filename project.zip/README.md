# Sentinel (phase 1)
Root monitor/firewall for Android 15 + KernelSU. Build with GitHub Actions (see build.yml).
